# ZONE OUT 2.0

这是一个独立静态网站，不依赖原网站的 `index.html`、外部地图 SDK 或第三方脚本。

## 本地预览
直接用浏览器打开 `index.html`。

## 发布到 GitHub Pages
1. 将本目录中的 `index.html` 上传到 GitHub 仓库中新建的文件夹（例如 `zone-out-2.0/`）。
2. 保持原仓库根目录的 `index.html` 不变。
3. 文件提交后访问 `https://你的用户名.github.io/仓库名/zone-out-2.0/`。
4. 如果你的仓库是 `用户名.github.io` 这种用户站点仓库，路径通常为 `https://用户名.github.io/zone-out-2.0/`。

## 重要说明
页面中的地点为用于展示交互的示例数据，地图为示意图，不是精确地图数据；发布前应替换为核实过的真实店名、地址与坐标。
